<template>
    <div class="texture">
      <div class="wrapper container">
        <div class="page-error">
          <h1 class="number text-center">404</h1>
          <h2 class="description text-center">Sorry, the pages you have visited do not exist!</h2>
          <h3 class="text-center">You can return to the home page from here <a href="/">index</a></h3>
        </div>
      </div>
    </div>
</template>

<script>
    export default {
        name: "notFound"
    }
</script>

<style scoped>
  html { height: 100%; }
  body {
    height: 100%;
    position: relative;
    padding: 0;
    background-color: #f6f6f6;
    font-family: "Open Sans",sans-serif;
    font-size: 12px;
    color: #555;
    margin-left: -20px;
  }
  .texture {
    background: black;
  }
  h1, h2, h3, h4, h5, h6, .h1, .h2, .h3, .h4, .h5, .h6 {
    font-family: 'Open Sans',sans-serif;
    font-weight: 300;
    text-align: center;
  }
  h2, h1:first-child {
    margin-top: 0;
  }
  .wrapper {
    display: table;
    width: 100%;
    position: absolute;
    height: 100%;
    padding-top: 50px;
    margin-right: 15px;
    margin-left: 15px;
  }
  .page-error {
    margin-top: 50px;
    margin-bottom: 40px;
  }
  .page-error .number {
    color: #fff;
    font-size: 150px;
    font-family: Arial;
    text-shadow: 1px 1px 5px rgba(0,0,0,0.6);
  }
  .page-error .description {
    color: #fff;
    font-size: 40px;
    text-shadow: 1px 1px 5px rgba(0,0,0,0.6);
  }
  .page-error h3 {
    color: #fff;
    text-shadow: 1px 1px 5px rgba(0,0,0,0.6);
  }
  .copy, .copy a {
    color: #c9d4f6;
    text-shadow: 1px 1px 0 rgba(0,0,0,0.3);
  }
</style>
