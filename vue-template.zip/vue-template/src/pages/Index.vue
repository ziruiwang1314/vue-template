<template>
  <div>
    {{getTestData}}
  </div>
</template>

<script>
    export default {
        name: "Index",
        components:{

        },
        props:{

        },
        data(){
            return{
              getTestData:{}
            }
        },
        created() {
        },
        mounted() {
            this.getHeadData()
        },
        activated() {
        },
        updated() {
        },
        beforeRouteUpdate:{

        },
        methods:{
            getHeadData(){
                let that = this
                this.$api.testAPI({})
                    .then(res=>{
                        that.getTestData = res.data.text
                    })
                    .catch(error=>{
                        console.log(error)
                    })
            }
        },
        computed:{

        },
        watch:{

        }
    }
</script>

<style scoped>

</style>
