import Vue from 'vue'
import Router from 'vue-router'

const index = ()=>import("@/pages/Index");
const NotFound = ()=>import("@/components/NotFound");
Vue.use(Router)

const routes = [
  // {
  //   path:"/",
  //   redirect:'/index'
  // },
  {
    path: '/',
    component: index,
    children: [
      {
        path: '/',
        component: index,
      },
    ]
  },
  {
    path: '*',
    component: NotFound
  }
]
export default new Router({
  routes
})
